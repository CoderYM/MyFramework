create sequence FRAMEWORK_SYS_MENU_SEQ
minvalue 1
maxvalue 9999999999999999999999999999
start with 100
increment by 1
cache 20;

create sequence FRAMEWORK_SYS_PERMISSION_SEQ
minvalue 1
maxvalue 9999999999999999999999999999
start with 100
increment by 1
cache 20;

create sequence FRAMEWORK_SYS_ROLE_SEQ
minvalue 1
maxvalue 9999999999999999999999999999
start with 100
increment by 1
cache 20;
create sequence FRAMEWORK_USER_ROLE_SEQ
minvalue 1
maxvalue 9999999999999999999999999999
start with 100
increment by 1
cache 20;
create sequence FRAMEWORK_PERM_ASSIGN_SEQ
minvalue 1
maxvalue 9999999999999999999999999999
start with 100
increment by 1
cache 20;
create sequence FRAMEWORK_USER_INF_SEQ
minvalue 1
maxvalue 9999999999999999999999999999
start with 100
increment by 1
cache 20;
create sequence FRAMEWORK_ACTION_LOG_SEQ
minvalue 1
maxvalue 9999999999999999999999999999
start with 100
increment by 1
cache 20;
